%Plot to show the 3D orbit of Mars around the sun%
tic
b = readmatrix("Ephemeris_Mars_Orbit.xlsx");

X_Pos_M = b(:,1);
Y_Pos_M = b(:,2);
Z_Pos_M = b(:,3);
Light_Time_M = b(:,4);
Range_M = b(:,5);
Range_Rate_M = b(:,6);

e = readmatrix("Ephemeris_Earth_Orbit.xlsx");

X_Pos_E = e(:,1);
Y_Pos_E = e(:,2);
Z_Pos_E = e(:,3);
Light_Time_E = e(:,4);
Range_E = e(:,5);
Range_Rate_E = e(:,6);

h = readmatrix("Earth_to_Mars_Data_Ephemeris.xlsx");
% g = table2array(f);
% h = str2double(g);

X_Pos_EtM = h(:,1);
Y_Pos_EtM = h(:,2);
Z_Pos_EtM = h(:,3);
Light_Time_EtM = h(:,4);
Range_EtM = h(:,5);
Range_Rate_EtM = h(:,6);
Time_Elapsed = linspace(1,961,961);

[X,Y,Z] = sphere;
r = 2.75e7;
X2 = X * r * 0.75;
Y2 = Y * r * 0.75;
Z2 = Z * r;

r2 = 1.25e7; 
X3 = X * r2 * 0.75;
Y3 = Y * r2 * 0.75;
Z3 = Z * r2;

r3 = 1.25e7; 
X4 = X * r3 * 0.75;
Y4 = Y * r3 * 0.75;
Z4 = Z * r3;

figure(1)
plot3(X_Pos_M,Y_Pos_M,Z_Pos_M,'Color','r',LineWidth=1.5)
hold on
plot3(X_Pos_E,Y_Pos_E,Z_Pos_E,'Color','g',LineWidth=1.5)
hold on
surf(X2,Y2,Z2)
hold on 
surf(X3 + (X_Pos_M(1)),Y3 + (Y_Pos_M(1)),Z3)
hold on
surf(X4 + (X_Pos_E(1)),Y4 + (Y_Pos_E(1)),Z4)
colormap([0 0 1])
box on
xlim([-2.5e8 2.5e8])
ylim([-2.5e8 2.5e8])
zlim([-2.5e8 2.5e8])
ax = gca;
ax.ZGrid = 'on';
ax.XGrid = 'on';
ax.YGrid = 'on';
% ax.plot3(X2,Y2,Z2)

toc

figure(2)
hold on 
grid on
plot(Time_Elapsed,Range_EtM,LineWidth=2)
hold off
xlabel('Time Elapsed (days)')
ylabel('Earth to Mars Range (km)')
title('Graph to show change in Distance between Earth and Mars over time')



