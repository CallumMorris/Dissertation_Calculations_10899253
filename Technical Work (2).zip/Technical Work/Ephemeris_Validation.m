% Epehemeris Validation %

[R,V,jd] = planet_elements_and_sv(4,2440400.5);

