% Pork Chop Plot - V2%


% ˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜˜
% Example_8_08
% ˜˜˜˜˜˜˜˜˜˜˜˜
%
% This program uses Algorithm 8.2 to solve Example 8.8.
%
% mu - gravitational parameter of the sun (kmˆ3/sˆ2)
% deg - conversion factor between degrees and radians
% pi - 3.1415926...
%
% planet_id - planet identifier:
% 1 = Mercury
% 2 = Venus
% 3 = Earth
% 4 = Mars
% 5 = Jupiter
% 6 = Saturn
% 7 = Uranus
% 8 = Neptune
% 9 = Pluto
% planet_name - name of the planet
%
% year - range: 1901 - 2099
% month - range: 1 - 12
% month_name - name of the month
% day - range: 1 - 31
% hour - range: 0 - 23
% minute - range: 0 - 60
% second - range: 0 - 60
%
% depart - [planet_id, year, month, day, hour, minute,
% second] at departure
% arrive - [planet_id, year, month, day, hour, minute,
% second] at arrival
%
% planet1 - [Rp1, Vp1, jd1]
% planet2 - [Rp2, Vp2, jd2]
% trajectory - [V1, V2]
%
% coe - orbital elements [h e RA incl w TA]
% where
% h = angular momentum (kmˆ2/s)
% e = eccentricity
% RA = right ascension of the ascending
% node (rad)
% incl = inclination of the orbit (rad)
% w = argument of perigee (rad)
% TA = true anomaly (rad)
% a = semimajor axis (km)
%
% jd1, jd2 - Julian day numbers at departure and arrival
% tof - time of flight from planet 1 to planet 2
% (days)
%
% Rp1, Vp1 - state vector of planet 1 at departure
% (km, km/s)
% Rp2, Vp2 - state vector of planet 2 at arrival
% (km, km/s)
% R1, V1 - heliocentric state vector of spacecraft at
% departure (km, km/s)
% R2, V2 - heliocentric state vector of spacecraft at
% arrival (km, km/s)
%
% vinf1, vinf2 - hyperbolic excess velocities at departure
% and arrival (km/s)
%
% User M-functions required: interplanetary, coe_from_sv,
% month_planet_names
% ------------------------------------------------------------
clear
deg = pi/180;
mu = 1.327124e11;
%...Data for planet 1:
planet_id_E = 3; % (earth)
% year = 1996;
% month = 11;
% day = 7;
% hour = 0;
% minute = 0;
% second = 0;
%...
depart = readmatrix("Sun_Earth_Cycle_16_05_2048_to_16_05_2049_Julian_Dates_100_Equal_Spacing.xlsx");
%...Data for planet 2:
planet_id_M = 4; % (Mars)
% year = 1997;
% month = 9;
% day = 12;
% hour = 0;
% minute = 0;
% second = 0;
%...
arrive =readmatrix("Sun_Mars_Cycle_16_11_2049_to_16_11_2050_Julian_Dates_100_Equal_Spacing.xlsx");


S = length(depart);
Pork_Chop = zeros(S,S);

%Matrices of Orbital Parameters %
h = zeros(S,S);           %Angular Momentum
e = zeros(S,S);           %Eccentricity
RAAN = zeros(S,S);        %Right Accension of Acsending Node
incl = zeros(S,S);        %Inclination to the ecliptic
w = zeros(S,S);           %Argument of perihelion
TA_d = zeros(S,S);        %True Anomaly at Departure
TA_a = zeros(S,S);        %True Anomaly at Arrival
SMA = zeros(S,S);         %Semimajor Axis
OP = zeros(S,S);          %Orbital Period
tof_array = zeros(S,S);   %Total time of Flight

h1 = waitbar(0,'Please wait...');
s = clock;


tic
for i = 1:length(depart)
    for j = 1:length(arrive)

[planet1, planet2, trajectory] = interplanetary(depart(i), arrive(j),planet_id_E,planet_id_M);
R1 = planet1(1,1:3);
Vp1 = planet1(1,4:6);
jd1 = planet1(1,7);
R2 = planet2(1,1:3);
Vp2 = planet2(1,4:6);
jd2 = planet2(1,7);
V1 = trajectory(1,1:3);
V2 = trajectory(1,4:6);
tof_array(i,j) = jd2 - jd1;
%...Equations 8.102 and 8.103:
vinf1 = V1 - Vp1;
vinf2 = V2 - Vp2;
dV1 = norm(vinf1);
dV2 = norm(vinf2);
Delta_V = dV1 + dV2;

Pork_Chop(i,j) = Delta_V;

%...Use Algorithm 4.1 to find the orbital elements of the
% spacecraft trajectory based on [Rp1, V1]...
coe = coe_from_sv(R1, V1);
% ... and [R2, V2]
coe2 = coe_from_sv(R2, V2);

h(i,j) = coe(1);           %Angular Momentum
e(i,j) = coe(2);           %Eccentricity
RAAN(i,j) = coe(3)/deg;    %Right Accension of Acsending Node
incl(i,j) = coe(4)/deg;    %Inclination to the ecliptic
w(i,j) = coe(5)/deg;       %Argument of perihelion
TA_d(i,j) = coe(6)/deg;    %True Anomaly at Departure
TA_a(i,j) = coe2(6)/deg;   %True Anomaly at Arrival
SMA(i,j) = coe(7);         %Semimajor Axis
if coe(2) < 1
    OP(i,j) = 2*pi/sqrt(mu)*coe(7)^1.5/24/3600;      %Orbital Period
else
    OP(i,j) = 0;
end

    end 
    if i==1
      is = etime(clock,s);
      esttime = is * S;
    end
     h1 = waitbar(i/S,h1,['remaining time =',num2str(esttime-etime(clock,s),'%4.1f'),'sec' ]);

end 
toc

Bound1 = 10;
Bound2 = 40;
Bound1_Surface = zeros(S,S) + Bound1;
Bound2_Surface = zeros(S,S) + Bound2;

figure(1)
surf(Pork_Chop);
shading interp
hold on 
surf(Bound1_Surface)
hold on 
surf(Bound2_Surface)
c = colorbar;
c.Label.String = 'ΔV (km/s)';
c.Label.FontSize = 20;
c.Label.FontWeight = 'bold';
xlabel('Departure Dates','FontSize',20,'FontWeight','bold')
ylabel('Arrival Dates','FontSize',20,'FontWeight','bold')


figure(2)
surf(tof_array')     %Change this to be days % 
colormap("winter")
c = colorbar;
c.Label.String = 'Time of Flight (days)';
c.Label.FontSize = 20;
c.Label.FontWeight = 'bold';
xlabel('Departure Dates','FontSize',20,'FontWeight','bold')
ylabel('Arrival Dates','FontSize',20,'FontWeight','bold')




%Heliocetnric Ranges and Cartesian Coordinates
R_sat = zeros(S^2,2*S);
X_sat = zeros(S^2,2*S);
Y_sat = zeros(S^2,2*S);
Z_sat = zeros(S^2,2*S);
radiation_matrix = zeros(S,S);    %Radiation Trajectory arrays summed within the for loop
AU = 1.496e8;                     % km

for k = 1:S
    for l = 1:S

TA_incr = linspace(TA_d(k,l),TA_a(k,l),2*S);

row = ((k - 1)*S) + l;

R_sat(row,:) = SMA(k,l).*(1 - e(k,l).^2)./(1 + e(k,l).*cosd(TA_incr)); 
X_sat(row,:) = R_sat(row,:).*cosd(RAAN(k,l)).*cosd(TA_incr + w(k,l)) - sind(RAAN(k,l)).*sind(TA_incr + w(k,l)).*cosd(incl(k,l));
Y_sat(row,:) = R_sat(row,:).*(sind(RAAN(k,l)).*cosd(TA_incr + w(k,l)) + cosd(RAAN(k,l)).*sind( TA_incr + w(k,l) )).*cosd(incl(k,l));
Z_sat(row,:) = R_sat(row,:).*sind( TA_incr + w(k,l) ).*sind(incl(k,l));

Rad = 717.*(((1.3813.*AU)./R_sat(row,:)).^2);
radiation_matrix(k,l) = sum(Rad);

    end 
end 


figure(3)
surf(radiation_matrix)     %Change this to be days % 
shading interp
colormap('Autumn')
c = colorbar;
c.Label.String = 'Radiation (W/m^2)';
c.Label.FontSize = 20;
c.Label.FontWeight = 'bold';
xlabel('Departure Dates','FontSize',20,'FontWeight','bold')
ylabel('Arrival Dates','FontSize',20,'FontWeight','bold')
zlabel('Total Radiation Incidence (W/m^2)','FontSize',20,'FontWeight','bold')




b = readmatrix("Ephemeris_Mars_Orbit_2049_50.xlsx");

X_Pos_M = b(:,1);
Y_Pos_M = b(:,2);
Z_Pos_M = b(:,3);

e1 = readmatrix("Ephemeris_Earth_Orbit_2048_49.xlsx");

X_Pos_E = e1(:,1);
Y_Pos_E = e1(:,2);
Z_Pos_E = e1(:,3);

e2 = readmatrix("Ephemeris_Mars_Orbit_2050_51.xlsx");

X_Pos_M2 = e2(:,1);
Y_Pos_M2 = e2(:,2);
Z_Pos_M2 = e2(:,3);


[X,Y,Z] = sphere;
r = 2.75e7;
X2 = X * r * 0.75;
Y2 = Y * r * 0.75;
Z2 = Z * r;

r2 = 1.25e7; 
X3 = X * r2 * 0.75;
Y3 = Y * r2 * 0.75;
Z3 = Z * r2;

r3 = 1.25e7; 
X4 = X * r3 * 0.75;
Y4 = Y * r3 * 0.75;
Z4 = Z * r3;


% Trajectories of Interest %

%Corresponding Rows - Changes with matrix size%

Coordinates = randi([1 S],2,15);

K = 1;
for p = 1:15
    while K == 1
        if (Pork_Chop(Coordinates(1,p),Coordinates(2,p)))<=Bound1 || (Pork_Chop(Coordinates(1,p),Coordinates(2,p)))>=Bound2
            Coordinates(1,p) = randi([1 S],1,1);
            Coordinates(2,p) = randi([1 S],1,1);
        else
            K = 2;
        end
    end 
end 



Row1 = ((Coordinates(1,1) - 1) * S) + Coordinates(2,1);
Row2 = ((Coordinates(1,2) - 1) * S) + Coordinates(2,2);
Row3 = ((Coordinates(1,3) - 1) * S) + Coordinates(2,3);
Row4 = ((Coordinates(1,4) - 1) * S) + Coordinates(2,4);
Row5 = ((Coordinates(1,5) - 1) * S) + Coordinates(2,5);
Row6 = ((Coordinates(1,6) - 1) * S) + Coordinates(2,6);
Row7 = ((Coordinates(1,7) - 1) * S) + Coordinates(2,7);
Row8 = ((Coordinates(1,8) - 1) * S) + Coordinates(2,8);
Row9 = ((Coordinates(1,9) - 1) * S) + Coordinates(2,9);
Row10 = ((Coordinates(1,10) - 1) * S) + Coordinates(2,10);
Row11 = ((Coordinates(1,11) - 1) * S) + Coordinates(2,11);
Row12 = ((Coordinates(1,12) - 1) * S) + Coordinates(2,12);
Row13 = ((Coordinates(1,13) - 1) * S) + Coordinates(2,13);
Row14 = ((Coordinates(1,14) - 1) * S) + Coordinates(2,14);
Row15 = ((Coordinates(1,15) - 1) * S) + Coordinates(2,15);

% Row6 = ((13 - 1) * S) + 9;

% Corresponding Cartesian Coordinates %

% X %

TrajX_1 = X_sat(Row1,:);
TrajX_2 = X_sat(Row2,:);
TrajX_3 = X_sat(Row3,:);
TrajX_4 = X_sat(Row4,:);
TrajX_5 = X_sat(Row5,:);
TrajX_6 = X_sat(Row6,:);
TrajX_7 = X_sat(Row7,:);
TrajX_8 = X_sat(Row8,:);
TrajX_9 = X_sat(Row9,:);
TrajX_10 = X_sat(Row10,:);
TrajX_11 = X_sat(Row11,:);
TrajX_12 = X_sat(Row12,:);
TrajX_13 = X_sat(Row13,:);
TrajX_14 = X_sat(Row14,:);
TrajX_15 = X_sat(Row15,:);
% TrajX_6 = X_sat(Row6,:);

TrajXs = [TrajX_1 ; TrajX_2 ; TrajX_3 ; TrajX_4 ; TrajX_5 ; TrajX_6 ; TrajX_7 ; TrajX_8 ; TrajX_9 ; TrajX_10 ; TrajX_11 ; TrajX_12 ; TrajX_13 ; TrajX_14 ; TrajX_15];


% Y %

TrajY_1 = Y_sat(Row1,:);
TrajY_2 = Y_sat(Row2,:);
TrajY_3 = Y_sat(Row3,:);
TrajY_4 = Y_sat(Row4,:);
TrajY_5 = Y_sat(Row5,:);
TrajY_6 = Y_sat(Row6,:);
TrajY_7 = Y_sat(Row7,:);
TrajY_8 = Y_sat(Row8,:);
TrajY_9 = Y_sat(Row9,:);
TrajY_10 = Y_sat(Row10,:);
TrajY_11 = Y_sat(Row11,:);
TrajY_12 = Y_sat(Row12,:);
TrajY_13 = Y_sat(Row13,:);
TrajY_14 = Y_sat(Row14,:);
TrajY_15 = Y_sat(Row15,:);
% TrajY_6 = Y_sat(Row6,:);

TrajYs = [TrajY_1 ; TrajY_2 ; TrajY_3 ; TrajY_4 ; TrajY_5 ; TrajY_6 ; TrajY_7 ; TrajY_8 ; TrajY_9 ; TrajY_10 ; TrajY_11 ; TrajY_12 ; TrajY_13 ; TrajY_14 ; TrajY_15];

% Z %

TrajZ_1 = Z_sat(Row1,:);
TrajZ_2 = Z_sat(Row2,:);
TrajZ_3 = Z_sat(Row3,:);
TrajZ_4 = Z_sat(Row4,:);
TrajZ_5 = Z_sat(Row5,:);
TrajZ_6 = Z_sat(Row6,:);
TrajZ_7 = Z_sat(Row7,:);
TrajZ_8 = Z_sat(Row8,:);
TrajZ_9 = Z_sat(Row9,:);
TrajZ_10 = Z_sat(Row10,:);
TrajZ_11 = Z_sat(Row11,:);
TrajZ_12 = Z_sat(Row12,:);
TrajZ_13 = Z_sat(Row13,:);
TrajZ_14 = Z_sat(Row14,:);
TrajZ_15 = Z_sat(Row15,:);
% TrajZ_6 = Z_sat(Row6,:);

TrajZs = [TrajZ_1 ; TrajZ_2 ; TrajZ_3 ; TrajZ_4 ; TrajZ_5 ; TrajZ_6 ; TrajZ_7 ; TrajZ_8 ; TrajZ_9 ; TrajZ_10 ; TrajZ_11 ; TrajZ_12 ; TrajZ_13 ; TrajZ_14 ; TrajZ_15];

colours = hsv(7);

figure(4)
plot3(X_Pos_M,Y_Pos_M,Z_Pos_M,'Color','r',LineWidth=1.5)
hold on
plot3(X_Pos_E,Y_Pos_E,Z_Pos_E,'Color','g',LineWidth=1.5)
hold on
plot3(X_Pos_M2,Y_Pos_M2,Z_Pos_M2,'Color','k',LineWidth=1.5,LineStyle='--')
hold on
plot3(TrajX_1,TrajY_1,TrajZ_1,LineWidth=1.5,Color='b')
hold on
plot3(TrajX_2,TrajY_2,TrajZ_2,LineWidth=1.5,Color='c')
hold on
plot3(TrajX_3,TrajY_3,TrajZ_3,LineWidth=1.5,Color='m')
hold on
plot3(TrajX_4,TrajY_4,TrajZ_4,LineWidth=1.5,Color='y')
hold on
plot3(TrajX_5,TrajY_5,TrajZ_5,LineWidth=1.5,Color='k')
hold on
surf(X2,Y2,Z2)
hold on 
surf(X3 + (X_Pos_M(1)),Y3 + (Y_Pos_M(1)),Z3)
hold on
surf(X4 + (X_Pos_E(1)),Y4 + (Y_Pos_E(1)),Z4)
colormap([0 0 1])
box on
xlim([-2.5e8 2.5e8])
ylim([-2.5e8 2.5e8])
zlim([-2.5e8 2.5e8])
ax = gca;
ax.ZGrid = 'on';
ax.XGrid = 'on';
ax.YGrid = 'on';
% ax.plot3(X2,Y2,Z2)

figure(5)
plot3(X_Pos_M,Y_Pos_M,Z_Pos_M,'Color','r',LineWidth=1.5)
hold on
plot3(X_Pos_E,Y_Pos_E,Z_Pos_E,'Color','g',LineWidth=1.5)
hold on
plot3(X_Pos_M2,Y_Pos_M2,Z_Pos_M2,'Color','k',LineWidth=1.5,LineStyle='--')
hold on
plot3(TrajX_6,TrajY_6,TrajZ_6,LineWidth=1.5,Color='b')
hold on
plot3(TrajX_7,TrajY_7,TrajZ_7,LineWidth=1.5,Color='c')
hold on
plot3(TrajX_8,TrajY_8,TrajZ_8,LineWidth=1.5,Color='m')
hold on
plot3(TrajX_9,TrajY_9,TrajZ_9,LineWidth=1.5,Color='y')
hold on
plot3(TrajX_10,TrajY_10,TrajZ_10,LineWidth=1.5,Color='k')
hold on
surf(X2,Y2,Z2)
hold on 
surf(X3 + (X_Pos_M(1)),Y3 + (Y_Pos_M(1)),Z3)
hold on
surf(X4 + (X_Pos_E(1)),Y4 + (Y_Pos_E(1)),Z4)
colormap([0 0 1])
box on
xlim([-2.5e8 2.5e8])
ylim([-2.5e8 2.5e8])
zlim([-2.5e8 2.5e8])
ax = gca;
ax.ZGrid = 'on';
ax.XGrid = 'on';
ax.YGrid = 'on';
% ax.plot3(X2,Y2,Z2)

figure(6)
plot3(X_Pos_M,Y_Pos_M,Z_Pos_M,'Color','r',LineWidth=1.5)
hold on
plot3(X_Pos_E,Y_Pos_E,Z_Pos_E,'Color','g',LineWidth=1.5)
hold on
plot3(X_Pos_M2,Y_Pos_M2,Z_Pos_M2,'Color','k',LineWidth=1.5,LineStyle='--')
hold on
plot3(TrajX_11,TrajY_11,TrajZ_11,LineWidth=1.5,Color='b')
hold on
plot3(TrajX_12,TrajY_12,TrajZ_12,LineWidth=1.5,Color='c')
hold on
plot3(TrajX_13,TrajY_13,TrajZ_13,LineWidth=1.5,Color='m')
hold on
plot3(TrajX_14,TrajY_14,TrajZ_14,LineWidth=1.5,Color='y')
hold on
plot3(TrajX_15,TrajY_15,TrajZ_15,LineWidth=1.5,Color='k')
hold on
surf(X2,Y2,Z2)
hold on 
surf(X3 + (X_Pos_M(1)),Y3 + (Y_Pos_M(1)),Z3)
hold on
surf(X4 + (X_Pos_E(1)),Y4 + (Y_Pos_E(1)),Z4)
colormap([0 0 1])
box on
xlim([-2.5e8 2.5e8])
ylim([-2.5e8 2.5e8])
zlim([-2.5e8 2.5e8])
ax = gca;
ax.ZGrid = 'on';
ax.XGrid = 'on';
ax.YGrid = 'on';
ax.plot3(X2,Y2,Z2)


