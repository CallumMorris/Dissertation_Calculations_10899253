% Basic Dissertation Graphs %

% 1 - Distance between Earth and Mars %
% This is the show the repeating cycle and therefore to what extent you5
% need to zoom in

a = readmatrix("Earth_Mars_Cycle_70_Years_Ephemeris.xlsx");
% c = table2array(a);
% b = str2double(c);

X_Pos_EMC = a(:,1);
Y_Pos_EMC = a(:,2);
Z_Pos_EMC = a(:,3);
Light_Time_EMC = a(:,4);
Range_EMC = a(:,5);
Range_Rate_EMC = a(:,6);
Time_Elapsed_1 = linspace(2024,2024+70,1827);

figure(1)
hold on 
grid on
plot(Time_Elapsed_1,Range_EMC,LineWidth=2)
xline(20+2024,'LineWidth',2.5,'Color','r','LineStyle','-')
xline(35+2024,'LineWidth',2.5,'Color','r','LineStyle','-')
hold off
xlim([2024 (70 + 2024)])
xlabel('Time (Years)','FontSize',20,'FontWeight','bold')
ylabel('Earth to Mars Range (km)','FontSize',20,'FontWeight','bold')
title('Change in Distance between Earth and Mars (2024 - 2094)','FontSize',25,'FontWeight','bold')

figure(2)
hold on 
grid on
plot(Time_Elapsed_1,Range_EMC,LineWidth=2)
hold off
xlim([(20 + 2024) (35 + 2024)])
xlabel('Time Elapsed (Years)')
ylabel('Earth to Mars Range (km)')
title('Graph to show change in Distance between Earth and Mars over 30 Years')

figure(3)
hold on 
grid on
plot(Time_Elapsed_1,Range_EMC,LineWidth=2)
xline(2048.25,'LineWidth',2.5,'Color','g','LineStyle','-')
xline(2049.25,'LineWidth',2.5,'Color','g','LineStyle','-')
xline(2049.75,'LineWidth',2.5,'Color','r','LineStyle','-')
xline(2050.75,'LineWidth',2.5,'Color','r','LineStyle','-')
hold off
xlim([(2047) (2054)])
xlabel('Time (Years)','FontSize',20,'FontWeight','bold')
ylabel('Earth to Mars Range (km)','FontSize',20,'FontWeight','bold')
title('Change in Distance between Earth and Mars (2047 - 2054)','FontSize',20,'FontWeight','bold')
legend('','Launch Window','','Arrival Window','FontSize',16,'FontWeight','bold')



% 2 - Communications between Earth and Mars %
% This is similar to the previous graph however must consider step function
% when behind sun. 


d = readmatrix("Sun_Earth_Cycle_70_Years_Ephemeris.xlsx");  %Input data between Sun and Earth
% e = table2array(d);
% f = str2double(e);

X_Pos_SEC = d(:,1);
Y_Pos_SEC = d(:,2);
Z_Pos_SEC = d(:,3);
Light_Time_SEC = d(:,4);
Range_SEC = d(:,5);
Range_Rate_SEC = d(:,6);



g = readmatrix("Sun_Mars_Cycle_70_Years_Ephemeris.xlsx");  %Input data between Sun and Mars
% h = table2array(g);
% k = str2double(h);

X_Pos_SMC = g(:,1);
Y_Pos_SMC = g(:,2);
Z_Pos_SMC = g(:,3);
Light_Time_SMC = g(:,4);
Range_SMC = g(:,5);
Range_Rate_SMC = g(:,6);   % Ranges are all in km

Sun_Proximity_Array = zeros(1827,1);
SEM_Angle = zeros(1827,1);
Communications_Array = zeros(1827,1);


for i = 1:1:1827

    SEM_Angle(i) = acosd((Range_SEC(i)^2 + Range_EMC(i)^2 - Range_SMC(i)^2)/(2 * Range_SEC(i) * Range_EMC(i)));
    Sun_Proximity_Array(i) = Range_SEC(i) * sind(SEM_Angle(i));
    if Range_EMC(i) < Range_SMC(i)
        Communications_Array(i) = 2 * Light_Time_EMC(i);
    else 
        if SEM_Angle(i) <= 10  % This number needs to be changed but for now it is a proof of concept. 
            Communications_Array(i) = inf;
        else
            Communications_Array(i) = 2 * Light_Time_EMC(i);
        end
    end
end


% figure(4)
% hold on 
% grid on
% plot(Time_Elapsed_1,Communications_Array,'LineWidth',1.5,'Color','b')
% xline(2048.25,'LineWidth',2.5,'Color','g','LineStyle','-')
% xline(2049.25,'LineWidth',2.5,'Color','g','LineStyle','-')
% xline(2049.75,'LineWidth',2.5,'Color','r','LineStyle','-')
% xline(2050.75,'LineWidth',2.5,'Color','r','LineStyle','-')
% hold off
% xlim([(2047) (2054)])
% xlabel('Time Elapsed (Years)')
% ylabel('Earth to Mars Communication Time (secs)')
% title('Graph to show change in Communication time between Earth and Mars over time')


% 3 - Radiation Between Mars and Earth Considering Atmosphere % 

% Find subsolar latitude for Mars and use this in the given equation to
% show how radiation changes through the 70 year period. 

% This is being done for the Eberswalde Crater located at ( lat: 24 deg
% south, long: 33.7 deg west. 

% Radiation for Mars is 717 Wm^-2 at the closest point of 1.3813 (June 22nd 2022) AU so this
% can be used a strength correction factor for distance. 

%This point will experience radiation every day so this calculation will
%find the peak radiation at the point where the sun is at high noon. Sub
%Solar latitude is taken from New Horizons database. 

Eberswalde_lat = 24.0; %deg
AU = 1.496e8; % km

a1 = readmatrix("Mars_Subsolar_Angles_70_Years_Ephemeris.xlsx");   %Input Subsolar Angle Data
% a2 = table2array(a1);

Subsolar_Longitude = a1(:,1);  % Sun incidence on Mars
Subsolar_Latitude = a1(:,2);

Sub_Long = abs(Subsolar_Longitude);
Sub_Lat = abs(Subsolar_Latitude);    %Absolute values taken as only angular component and not direction is considered significant. 

Mars_Radiation = zeros(1827,1);

for j = 1:1:1827

    Mars_Radiation(j) = 717 * (((1.3813 * AU)/Range_SMC(j))^2) * cosd(Eberswalde_lat - Sub_Lat(j));
end 


figure(4)
hold on 
grid on
plot(Time_Elapsed_1,Communications_Array,'LineWidth',3,'Color','b')
xline(2048.25,'LineWidth',2.5,'Color','g','LineStyle','-')
xline(2049.25,'LineWidth',2.5,'Color','g','LineStyle','-')
xline(2049.4,'LineWidth',2.5,'Color','r','LineStyle','-')
xline(2050.4,'LineWidth',2.5,'Color','r','LineStyle','-')
hold off
xlim([(2047) (2054)])
xlabel('Time (Years)','FontSize',20,'FontWeight','bold')
ylabel('Communication Time (Secs)','FontSize',20,'FontWeight','bold')
title('Change in Communication time between Earth and Mars (2047 - 2054)','FontSize',20,'FontWeight','bold')
% legend('','Launch Window','','Arrival Window','FontSize',14,'FontWeight','bold')

figure(5)
hold on 
grid on
plot(Time_Elapsed_1,Mars_Radiation,'LineWidth',3,'Color','k','LineStyle','-')
xline(2049.4,'LineWidth',2.5,'Color','r','LineStyle','-')
xline(2050.4,'LineWidth',2.5,'Color','r','LineStyle','-')
hold off
xlim([(2047) (2054)])
xlabel('Time (Years)','FontSize',20,'FontWeight','bold')
ylabel('Radiation Incidence (W/m^2)','FontSize',20,'FontWeight','bold')
title('Change in Solar Radiation at Eberswalde Crater, Mars (2047 - 2054)','FontSize',20,'FontWeight','bold')


% hold on 
% grid on
% plot(Time_Elapsed_1,Mars_Radiation,'LineWidth',2,'Color','g')
% hold off
% xlim([(25 + 2024) (30 + 2024)])
% xlabel('Time Elapsed (Years)')
% ylabel('Earth to Mars Radiation Incidence (secs)')
% title('Graph to show change in Radiation Incidence on Mars surface over time')

figure(6)
hold on 
grid on
plot(Time_Elapsed_1,Mars_Radiation,'LineWidth',3,'Color','k','LineStyle','-')
plot(Time_Elapsed_1,Communications_Array,'LineWidth',3,'Color','b')
xline(2048.25,'LineWidth',2.5,'Color','g','LineStyle','-')
xline(2049.25,'LineWidth',2.5,'Color','g','LineStyle','-')
xline(2049.4,'LineWidth',2.5,'Color','r','LineStyle','-')
xline(2050.4,'LineWidth',2.5,'Color','r','LineStyle','-')
hold off
xlim([(2047) (2054)])
xlabel('Time Elapsed (Years)')
ylabel('Communication Time (secs)')
title('Graph to show change in Communication time between Earth and Mars over time')
legend('Radiation Variance','Communication Variance','','Launch Window','','Arrival Window','FontSize',14,'FontWeight','bold')

figure(7)
hold on 
grid on
plot(Time_Elapsed_1,Communications_Array,'LineWidth',3,'Color','b')
xline(2048.25,'LineWidth',2.5,'Color','g','LineStyle','-')
xline(2049.25,'LineWidth',2.5,'Color','g','LineStyle','-')
xline(2049.4,'LineWidth',2.5,'Color','r','LineStyle','-')
xline(2050.4,'LineWidth',2.5,'Color','r','LineStyle','-')
hold off
xlim([(2024) (2031)])
xlabel('Time (Years)','FontSize',20,'FontWeight','bold')
ylabel('Communication Time (Secs)','FontSize',20,'FontWeight','bold')
title('Validation of Solar Conjunctions between Earth and Mars (2024 - 2031)','FontSize',20,'FontWeight','bold')
% legend('','Launch Window','','Arrival Window','FontSize',14,'FontWeight','bold')







