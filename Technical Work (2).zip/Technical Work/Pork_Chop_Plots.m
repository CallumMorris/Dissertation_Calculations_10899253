% Initial Pork Chop Plots %

%Key Notes%

% - Ephemeris data is needed to understand the heliocentric positions of
% plants relative to each other before anything else can be done. A way to
% download this data in to MATLAB needs to be found. 

% - An initial Parking Orbit needs to be chosen with parameters given 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 1 - Practice Pork Chop Plot

Time_Gap = 0.5; % Time to travel in years  (Find a paper to back up time frame chosen)
Total_Range = 1*365*24*3600;   % 5 Years in seconds 
Time_Taken = Time_Gap*365*24*3600; 
S = 20; % Matrix Size for Plot   
depart = (linspace(0,Total_Range,S))';
arrival = (linspace((Total_Range + Time_Taken),((2 * Total_Range) + Time_Taken),S))';
b3 = readmatrix("Sun_Earth_Cycle_16_05_2048_to_16_05_2049_Ephemeris.xlsx");
c3 = readmatrix("Sun_Mars_Cycle_16_11_2049_to_16_11_2050_Ephemeris.xlsx");
% d3 = readmatrix("Sun_Earth_Cycle_Velocities_70_Years_Ephemeris.xlsx");
% e3 = readmatrix("Sun_Mars_Cycle_Velocities_70_Years_Ephemeris.xlsx");

l = length(b3(:,1));

X_Pos_SEC = zeros(S,1);
Y_Pos_SEC = zeros(S,1);
Z_Pos_SEC = zeros(S,1);
Light_Time_SEC = zeros(S,1);
Range_SEC = zeros(S,1);
Range_Rate_SEC = zeros(S,1);
X_Vel_SEC = zeros(S,1);
Y_Vel_SEC = zeros(S,1);
Z_Vel_SEC = zeros(S,1);

X_Pos_SMC= zeros(S,1);
Y_Pos_SMC = zeros(S,1);
Z_Pos_SMC = zeros(S,1);
Light_Time_SMC = zeros(S,1);
Range_SMC = zeros(S,1);
Range_Rate_SMC = zeros(S,1);
X_Vel_SMC = zeros(S,1);
Y_Vel_SMC = zeros(S,1);
Z_Vel_SMC = zeros(S,1);

for k = 1:1:S

    z = floor((l/S)*k);

    X_Pos_SEC(k,1) = b3(z,1);
    Y_Pos_SEC(k,1) = b3(z,2);
    Z_Pos_SEC(k,1) = b3(z,3);
    Light_Time_SEC(k,1) = b3(z,7);
    Range_SEC(k,1) = b3(z,8);
    Range_Rate_SEC(k,1) = b3(z,9);
    X_Vel_SEC(k,1) = b3(z,4);
    Y_Vel_SEC(k,1) = b3(z,5);
    Z_Vel_SEC(k,1) = b3(z,6);


    X_Pos_SMC(k,1) = c3(z,1);
    Y_Pos_SMC(k,1) = c3(z,2);
    Z_Pos_SMC(k,1) = c3(z,3);
    Light_Time_SMC(k,1) = c3(z,7);
    Range_SMC(k,1) = c3(z,8);
    Range_Rate_SMC(k,1) = c3(z,9);
    X_Vel_SMC(k,1) = c3(z,4);
    Y_Vel_SMC(k,1) = c3(z,5);
    Z_Vel_SMC(k,1) = c3(z,6);
end 

Porkchop_Practice_Plot = zeros(S,S);
% V1_Practice = zeros(1827,1);
% V2_Practice = zeros(1827,1);

% Define R1 and R2 in a for loop before function calculations
delta_t = zeros(S,S);
tic

for i = 1:1:S
    for j = 1:1:S
        delta_t(j,i) = arrival(j) - depart(i);

        [V1_Practice,V2_Practice] = lambert([X_Pos_SEC(i), Y_Pos_SEC(i), Z_Pos_SEC(i)],[X_Pos_SMC(j), Y_Pos_SMC(j), Z_Pos_SMC(j)],delta_t(j,i),"pro");
        
        dV1 = abs(norm(V1_Practice) - norm([X_Vel_SEC(i),Y_Vel_SEC(i),Z_Vel_SEC(i)]));
        dV2 = abs(norm(V2_Practice) - norm([X_Vel_SMC(j),Y_Vel_SMC(j),Z_Vel_SMC(j)]));

        Delta_V = dV1 + dV2;

        % if Delta_V >= 15
        % 
        %     Porkchop_Practice_Plot(i,j) = 0;
        % 
        % else 
        %     Porkchop_Practice_Plot(i,j) =  Delta_V;
        % end 
         Porkchop_Practice_Plot(i,j) =  Delta_V;
    end 
end 
toc

surf(Porkchop_Practice_Plot)
shading interp
c = colorbar;
c.Label.String = 'ΔV (km/s)';
c.Label.FontSize = 20;
c.Label.FontWeight = 'bold';
xlabel('Departure Dates','FontSize',20,'FontWeight','bold')
ylabel('Arrival Dates','FontSize',20,'FontWeight','bold')


% surf(delta_t)
% xlabel('Departure Dates','FontSize',20,'FontWeight','bold')
% ylabel('Arrival Dates','FontSize',20,'FontWeight','bold')






