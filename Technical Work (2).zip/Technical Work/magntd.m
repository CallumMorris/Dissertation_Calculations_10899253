function M = magntd(x,y,z)

M = sqrt(x.^2 + y.^2 + z.^2);