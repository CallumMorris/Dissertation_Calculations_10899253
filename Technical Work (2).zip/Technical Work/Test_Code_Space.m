[x,y] = planetary_elements(3);
t = [1 2 3 4 5 5 3 5 5 3 2 2 4 5 3 2 4 5 3 2 4 5 3 2 3 2 2 333 555 332 245 66];

e = zeros(length(t),length(x));
for i = 1:length(t)
    e(i,:) = x + y.*t(i);
end 

z = ones(10,10);
xx = 10.*tan(z);



% Julian Day Verification %

Jd1 = 2460412.5000000;
Jd2 = 2460777.5000000;

tof = Jd2 - Jd1;



data = peaks(30);
h = surf(data);
shading interp
for j = 1:25
    for k = 1:25
        if data(j,k) >= 4 || data(j,k) <= -2
            data(j,k) = NaN;
        end 
    end 
end 
% data(4,4) = NaN;
set(h, 'zdata', data)
