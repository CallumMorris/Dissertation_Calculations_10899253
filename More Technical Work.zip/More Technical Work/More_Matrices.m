% More Matrices and Sensitivity Analysis % 
tic
X_Sat1 = load("Xsat_Array.mat");
X_sat = cell2mat(struct2cell(X_Sat1));
Y_Sat1 = load("Ysat_Array.mat");
Y_sat = cell2mat(struct2cell(Y_Sat1));
Z_Sat1 = load("Zsat_Array.mat");
Z_sat = cell2mat(struct2cell(Z_Sat1));
Porkchop1 = load("Porkcop_Array.mat");
Porkchop = cell2mat(struct2cell(Porkchop1));

depart_crt = readmatrix("Sun_Earth_Cycle_16_05_2048_to_16_05_2049_Julian_Dates_500_Equal_Spacing_Cartesian.xlsx");
arrive_crt = readmatrix("Sun_Mars_Cycle_16_11_2049_to_16_11_2050_Julian_Dates_500_Equal_Spacing_Cartesian.xlsx");

X_start = X_sat(:,1);
X_end = X_sat(:,1002);
Y_start = Y_sat(:,1);
Y_end = Y_sat(:,1002);
Z_start = Z_sat(:,1);
Z_end = Z_sat(:,1002);

X_depart = depart_crt(:,1);
Y_depart = depart_crt(:,2);
Z_depart = depart_crt(:,3);
X_arrive = arrive_crt(:,1);
Y_arrive = arrive_crt(:,2);
Z_arrive = arrive_crt(:,3);

Sat_start = [X_start Y_start Z_start];
Sat_end = [X_end Y_end Z_end];


S = length(X_start);
% X_dis = zeros(S,S);
% Y_dis = zeros(S,S);
% Z_dis = zeros(S,S);

Upper = 1.5;
Lower = 0.5;

h1 = waitbar(0,'Please wait...');
cl = clock;


h = surf(Porkchop);
shading interp

count = linspace(1,S,S);


for i = 1:1:S
    v = floor(count(i)/501);
    % v1 = ceil(i/501);
    y = v + 1;
    x = count(i) - (v*501);

    if abs(X_start(i,1)) >= (abs(X_depart(x,1)) * Upper) || abs(X_start(i,1)) <= (abs(X_depart(x,1)) * Lower)
        Porkchop(x,y) = NaN;
    elseif abs(X_end(i,1)) >= (abs(X_arrive(y,1)) * Upper) || abs(X_end(i,1)) <= (abs(X_arrive(y,1)) * Lower)
        Porkchop(x,y) = NaN;
    elseif abs(Y_start(i,1)) >= (abs(Y_depart(x,1)) * Upper) || abs(Y_start(i,1)) <= (abs(Y_depart(x,1)) * Lower)
        Porkchop(x,y) = NaN;
    elseif abs(Y_end(i,1)) >= (abs(Y_arrive(y,1)) * Upper) || abs(Y_end(i,1)) <= (abs(Y_arrive(y,1)) * Lower)
        Porkchop(x,y) = NaN;
    elseif abs(Z_start(i,1)) >= (abs(Z_depart(x,1)) * Upper) || abs(Z_start(i,1)) <= (abs(Z_depart(x,1)) * Lower)
        Porkchop(x,y) = NaN;
    elseif abs(Z_end(i,1)) >= (abs(Z_arrive(y,1)) * Upper) || abs(Z_end(i,1)) <= (abs(Z_arrive(y,1)) * Lower)
        Porkchop(x,y) = NaN;
    end 
    
    if i==1
      is = etime(clock,cl);
      esttime = is * S;
    end
     h1 = waitbar(i/S,h1,['remaining time =',num2str(esttime-etime(clock,cl),'%4.1f'),'sec' ]);

end 
set(h, 'zdata', data)

toc 


% THIS TAKES TWO DAYS, CLOSE THIS!!!! %
