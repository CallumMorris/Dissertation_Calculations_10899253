% Relative_Distance %
X_Sat1 = load("Xsat_Array_Size_101.mat");
X_sat = cell2mat(struct2cell(X_Sat1));
Y_Sat1 = load("Ysat_Array_Size_101.mat");
Y_sat = cell2mat(struct2cell(Y_Sat1));
Z_Sat1 = load("Zsat_Array_Size_101.mat");
Z_sat = cell2mat(struct2cell(Z_Sat1));
tof1 = load("tof_array_size_101.mat");
tof = (cell2mat(struct2cell(tof1)))';
tof2 = load("Time_Of_Flight_Array.mat");
tof_big = (cell2mat(struct2cell(tof2)))';
load('slanCM_Data.mat')
Radiation_Array1 = load("Radiation_Array_Size_101.mat");
Radiation_Array = cell2mat(struct2cell(Radiation_Array1));
Porkchop1 = load("Porkcop_Array_Size_101.mat");
Porkchop = cell2mat(struct2cell(Porkchop1));




depart_crt = readmatrix("Sun_Earth_Cycle_16_05_2048_to_16_05_2049_Julian_Dates_101_Equal_Spacing_JD_and_Cartesian.xlsx");
arrive_crt = readmatrix("Sun_Mars_Cycle_16_11_2049_to_16_11_2050_Julian_Dates_101_Equal_Spacing_JD_and_Cartesian.xlsx");

S = length(depart_crt);

JD_1 = depart_crt(:,1);
JD_2 = arrive_crt(:,1);


X_start = X_sat(:,1);
X_end = X_sat(:,202);
Y_start = Y_sat(:,1);
Y_end = Y_sat(:,202);
Z_start = Z_sat(:,1);
Z_end = Z_sat(:,202);

X_depart = depart_crt(:,2);
Y_depart = depart_crt(:,3);
Z_depart = depart_crt(:,4);
X_arrive = arrive_crt(:,2);
Y_arrive = arrive_crt(:,3);
Z_arrive = arrive_crt(:,4);

Sat_start = [X_start Y_start Z_start];
Sat_end = [X_end Y_end Z_end];

X_Earth = zeros(S^2,2*S);
Y_Earth = zeros(S^2,2*S);
Z_Earth = zeros(S^2,2*S);
x = zeros(1,S);
y = zeros(1,S);
v = zeros(1,S);

h1 = waitbar(0,'Please wait...');
s = clock;

tic
for i = 1:1:S^2
    for j = 1:1:202
        
        z = i/101;
        v(i) = floor(z);

        if int8(z) == z
            y(i) = v(i);
            x(i) = 101;
        else
            y(i) = v(i) + 1;
            x(i) = i - (v(i)*101);
        end 

        step = tof(x(i),y(i))/202;
        Julian = JD_1(x(i),1) + (step * j);
        [R,~,~] = planet_elements_and_sv(3,Julian);

        X_Earth(i,j) = R(1,1);
        Y_Earth(i,j) = R(1,2);
        Z_Earth(i,j) = R(1,3);

    end
    
    if i==1
      is = etime(clock,s);
      esttime = is * S;
    end
     h1 = waitbar(i/S,h1,['remaining time =',num2str(esttime-etime(clock,s),'%4.1f'),'sec' ]);
end 

Rel_Dis_X = X_Earth - X_sat;
Rel_Dis_Y = Y_Earth - Y_sat;
Rel_Dis_Z = Z_Earth - Z_sat;


avg_x = mean(Rel_Dis_X,2);
avg_y = mean(Rel_Dis_Y,2);
avg_z = mean(Rel_Dis_Z,2);

sqr_x = (avg_x).^2;
sqr_y = (avg_y).^2;
sqr_z = (avg_z).^2;

Sum_Sqr = sqr_x + sqr_y + sqr_z;
Magnitude = (Sum_Sqr).^0.5;

Relative_Distances = zeros(S,S);
x1 = zeros(1,S);
y1 = zeros(1,S);
v1 = zeros(1,S);

for k = 1:1:S^2
    
    z1 = k/101;
    v1(k) = floor(z1);
    
    if int8(z1) == z1
        y1(k) = v1(k);
        x1(k) = 101;
    else
        y1(k) = v1(k) + 1;
        x1(k) = k - (v1(k)*101);
    end 

    Relative_Distances(x1(k),y1(k)) = Magnitude(k,1);

end 

C = 299792458e-3;

Communication_Time = 2.*(Relative_Distances./C);
toc

cl1 = slanCM('emerald',800);
Cl1_1 = cl1(300:800,:);

figure(1)
surf(Relative_Distances)
shading interp
colormap(Cl1_1)
colorbar




figure(2)
surf(Communication_Time)
shading interp
cl3 = slanCM('YlOrBr',200);
Cl3_1 = flip(cl3);
colormap(Cl3_1)
colorbar

x2 = zeros(1,S);
y2 = zeros(1,S);
v2 = zeros(1,S);


% Sensitivity Analysis %

Normalised_Radiation = Radiation_Array./(max(max(Radiation_Array)));
Normalised_RelDis = Relative_Distances./(max(max(Relative_Distances)));
Normalised_Comms = Communication_Time./(max(max(Communication_Time)));
Normalised_Porkchop = Porkchop./(max(max(Porkchop)));
Normalised_tof = tof./(max(max(tof)));
Weightings_Matrix = [0.2 0.2 0.2 0.2 0.2 ; 0.6 0.1 0.1 0.1 0.1 ; 0.1 0.6 0.1 0.1 0.1 ; 0.1 0.1 0.6 0.1 0.1 ; 0.1 0.1 0.1 0.6 0.1 ; 0.1 0.1 0.1 0.1 0.6 ; 0.35 0.35 0.1 0.1 0.1 ; 0.45 0.45 0.033333 0.033333 0.033333];
MinVal_and_Coordinate_Matrix = zeros(3,8);
Value_Matrix = zeros(8,5);
Names = ["All Equal" "Radiation" "DeltaV" "Distance" "Communication" "Time of Flight" "Radiation and DeltaV (0.35)" "Radiation and DeltaV (0.45)"];
Nums = ["1" "2" "3" "4" "5" "6" "7" "8"];

for l = 1:1:8
Absolute_Score = (Normalised_Radiation.*(Weightings_Matrix(l,1))) + (Normalised_Porkchop.*(Weightings_Matrix(l,2))) + (Normalised_RelDis.*(Weightings_Matrix(l,3))) + (Normalised_Comms.*(Weightings_Matrix(l,4))) + (Normalised_tof.*(Weightings_Matrix(l,5)));
Normalised_Score = Absolute_Score./(max(max(Absolute_Score)));

[row, col] = find(ismember(Normalised_Score, min(Normalised_Score(:))));

MinVal_and_Coordinate_Matrix(1,l) = Normalised_Score(row,col);
MinVal_and_Coordinate_Matrix(2,l) = row;
MinVal_and_Coordinate_Matrix(3,l) = col;

Value_Matrix(l,1) = Normalised_Radiation(row,col);
Value_Matrix(l,2) = Normalised_Porkchop(row,col);
Value_Matrix(l,3) = Normalised_RelDis(row,col);
Value_Matrix(l,4) = Normalised_Comms(row,col);
Value_Matrix(l,5) = Normalised_tof(row,col);

end 


cl2 = slanCM('freeze',800);
Cl2_1 = cl2(250:800,:);

figure(3)
surf(Normalised_Score)
shading interp
colormap(Cl2_1)
colorbar

traj_row = ((row - 1)*S) + col;
X_Sat_Solution = X_sat(traj_row,:);
Y_Sat_Solution = Y_sat(traj_row,:);
Z_Sat_Solution = Z_sat(traj_row,:);


b = readmatrix("Ephemeris_Mars_Orbit_2049_50.xlsx");

X_Pos_M = b(:,1);
Y_Pos_M = b(:,2);
Z_Pos_M = b(:,3);

e1 = readmatrix("Ephemeris_Earth_Orbit_2048_49.xlsx");

X_Pos_E = e1(:,1);
Y_Pos_E = e1(:,2);
Z_Pos_E = e1(:,3);

e2 = readmatrix("Ephemeris_Mars_Orbit_2050_51.xlsx");

X_Pos_M2 = e2(:,1);
Y_Pos_M2 = e2(:,2);
Z_Pos_M2 = e2(:,3);


[X,Y,Z] = sphere;
r = 2.75e7;
X2 = X * r * 0.75;
Y2 = Y * r * 0.75;
Z2 = Z * r;

r2 = 1.25e7; 
X3 = X * r2 * 0.75;
Y3 = Y * r2 * 0.75;
Z3 = Z * r2;

r3 = 1.25e7; 
X4 = X * r3 * 0.75;
Y4 = Y * r3 * 0.75;
Z4 = Z * r3;

figure(4)
plot3(X_Pos_M,Y_Pos_M,Z_Pos_M,'Color','r',LineWidth=1.5,DisplayName='Mars Arrival Window')
hold on
plot3(X_Pos_E,Y_Pos_E,Z_Pos_E,'Color','g',LineWidth=1.5,DisplayName='Earth Departure Window')
hold on
plot3(X_Pos_M2,Y_Pos_M2,Z_Pos_M2,'Color','k',LineWidth=1.5,LineStyle='--',HandleVisibility='off')
hold on
plot3(X_Sat_Solution,Y_Sat_Solution,Z_Sat_Solution,LineWidth=2,Color='b',DisplayName='Solution Trajectory')
hold on
surf(X2,Y2,Z2,HandleVisibility="off")
hold on 
surf(X3 + (X_Pos_M(1)),Y3 + (Y_Pos_M(1)),Z3,HandleVisibility="off")
hold on
surf(X4 + (X_Pos_E(1)),Y4 + (Y_Pos_E(1)),Z4,HandleVisibility="off")
colormap([0 0 1])
box on
xlim([-2.5e8 2.5e8])
ylim([-2.5e8 2.5e8])
zlim([-2.5e8 2.5e8])
ax = gca;
ax.ZGrid = 'on';
ax.XGrid = 'on';
ax.YGrid = 'on';
% ax.plot3(X2,Y2,Z2)
legend

figure(5)
surf(tof_big)     %Change this to be days % 
colormap("winter")
shading interp
c = colorbar;
c.Label.String = 'Time of Flight (days)';
c.Label.FontSize = 20;
c.Label.FontWeight = 'bold';
xlabel('Departure Dates','FontSize',20,'FontWeight','bold')
ylabel('Arrival Dates','FontSize',20,'FontWeight','bold')


figure(6)
bar(Nums,Value_Matrix(:,1),"red")
ylim([0 0.6])
xlabel('Test Number','FontName','Arial','FontSize',20,'FontWeight','bold')
ylabel('Normalised Score','FontName','Arial','FontSize',20,'FontWeight','bold')
title('Change in Normalised Radiation Score with a Change in Weighting','FontName','Arial','FontSize',20,'FontWeight','bold')

figure(7)
bar(Nums,Value_Matrix(:,2),"green")
ylim([0 0.6])
xlabel('Test Number','FontName','Arial','FontSize',20,'FontWeight','bold')
ylabel('Normalised Score','FontName','Arial','FontSize',20,'FontWeight','bold')
title('Change in Normalised DeltaV Score with a Change in Weighting','FontName','Arial','FontSize',20,'FontWeight','bold')

figure(8)
bar(Nums,Value_Matrix(:,3),"blue")
ylim([0 0.6])
xlabel('Test Number','FontName','Arial','FontSize',20,'FontWeight','bold')
ylabel('Normalised Score','FontName','Arial','FontSize',20,'FontWeight','bold')
title('Change in Normalised Relative Distance Score with a Change in Weighting','FontName','Arial','FontSize',20,'FontWeight','bold')

figure(9)
bar(Nums,Value_Matrix(:,4),"black")
ylim([0 0.6])
xlabel('Test Number','FontName','Arial','FontSize',20,'FontWeight','bold')
ylabel('Normalised Score','FontName','Arial','FontSize',20,'FontWeight','bold')
title('Change in Normalised Communication Score with a Change in Weighting','FontName','Arial','FontSize',20,'FontWeight','bold')

figure(10)
bar(Nums,Value_Matrix(:,5),"yellow")
ylim([0 0.6])
xlabel('Test Number','FontName','Arial','FontSize',20,'FontWeight','bold')
ylabel('Normalised Score','FontName','Arial','FontSize',20,'FontWeight','bold')
title('Change in Normalised Time of Flight Score with a Change in Weighting','FontName','Arial','FontSize',20,'FontWeight','bold')

figure(11)
hold on
scatter(MinVal_and_Coordinate_Matrix(2,:),MinVal_and_Coordinate_Matrix(3,:),'blue','filled','o','LineWidth',2)
xlim([0 101])
ylim([0 101])
text(37,55,'Test 1 and 7','FontWeight','bold','FontSize',12)
text(2,101,'Test 2 and 6','FontWeight','bold','FontSize',12)
text(43,61,'Test 3','FontWeight','bold','FontSize',12)
text(51,55,'Test 4 and 5','FontWeight','bold','FontSize',12)
text(47,49,'Test 8','FontWeight','bold','FontSize',12)
hold off
xlabel('Departure Dates','FontName','Arial','FontSize',20,'FontWeight','bold')
ylabel('Arrival Dates','FontName','Arial','FontSize',20,'FontWeight','bold')
title('Graph showing the location of Utility Function Minimum Point for 8 Different Tests','FontName','Arial','FontSize',22,'FontWeight','bold')


figure(12)
bar(Nums,MinVal_and_Coordinate_Matrix(1,:))
ylim([0 0.6])
xlabel('Test Number','FontName','Arial','FontSize',20,'FontWeight','bold')
ylabel('Normalised Score','FontName','Arial','FontSize',20,'FontWeight','bold')
title('Change in Total Normalised Flight Score for Most Optimal Point with a Change in Weighting','FontName','Arial','FontSize',20,'FontWeight','bold')


[row1, col1] = find(ismember(Porkchop, min(Porkchop(:))));
min_km_s = Porkchop(row1,col1);
x12 = tof(row1,col1);
