
S = 501^2;

x = zeros(1,S);
y = zeros(1,S);
v = zeros(1,S);



for i = 1:1:S
    z = i/501;
    v(i) = floor(z);
    if int8(z) == z
        y(i) = v(i);
        x(i) = 501;
    else
        y(i) = v(i) + 1;
        x(i) = i - (v(i)*501);
    end 
end 


